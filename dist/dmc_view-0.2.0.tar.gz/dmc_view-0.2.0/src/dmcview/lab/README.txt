Focus on https://stackoverflow.com/questions/tagged/qpainter
understand:
 1- Image Overlay
 2- Scalable image or responsive image in QT 
 3-Static Image : It means you have a static image (circle) and it is scalable 
   which mean it can be adjust to different screen size ( see svg or Alan gives more)
   see https://stackoverflow.com/questions/19199863/draw-rectangular-overlay-on-qwidget-at-click
   Now overlay means you have static image and on top of it you redraw you staff ( dynamic). You DO NOT 
   want to draw the same image again and again ( circle and its background and symbol on it etc) since it cost (rendering and 
  painting cost )

4- QT Overlay:
see https://stackoverflow.com/search?q=qt++%2B+overlay  and pick the correct answer to have some feeling and understand OK

